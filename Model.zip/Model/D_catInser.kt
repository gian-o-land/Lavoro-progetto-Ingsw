package Model

enum class D_catInser {
    VENDITA,
    AFFITTO
}