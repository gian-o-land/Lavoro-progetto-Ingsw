package Model

enum class D_foto {
    PLANIMETRIA,
    FOTO
}