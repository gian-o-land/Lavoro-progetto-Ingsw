package Model

enum class D_formato {
    PNG,
    JPG,
    JPEG
}