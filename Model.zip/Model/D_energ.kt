package Model

enum class D_energ {
    ALTA,
    MEDIA,
    BASSA
}