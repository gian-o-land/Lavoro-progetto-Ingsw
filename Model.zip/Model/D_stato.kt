package Model

enum class D_stato {
    ACCETTATA,
    RIFIUTATA,
    ATTESA
}