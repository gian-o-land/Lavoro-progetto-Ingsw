package Model

enum class D_arred {
    COMPLETO,
    PARZIALE,
    NO
}