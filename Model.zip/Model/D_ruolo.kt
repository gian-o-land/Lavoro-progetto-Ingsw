package Model

enum class D_ruolo {
    ADMIN,
    SOTTOADMIN
}