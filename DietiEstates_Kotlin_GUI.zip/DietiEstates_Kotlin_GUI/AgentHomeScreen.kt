import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.ui.tooling.preview.Preview

data class Immobile(val prezzo: String, val comune: String, val indirizzo: String)

@Composable
fun AgentHomeScreen(
    immobili: List<Immobile>,
    onAddPropertyClick: () -> Unit,
    onNotificheClick: () -> Unit,
    onProfiloClick: () -> Unit
) {
    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)) {

        Text("Pagina Agente", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(modifier = Modifier.weight(1f)) {
            items(immobili) { immobile ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("€${immobile.prezzo}", style = MaterialTheme.typography.titleMedium)
                        Text(\"${immobile.comune} - ${immobile.indirizzo}\")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            horizontalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(onClick = onAddPropertyClick) {
                Text("Aggiungi immobile")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            horizontalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(onClick = onNotificheClick) {
                Text("Notifiche")
            }
            Button(onClick = onProfiloClick) {
                Text("Profilo")
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewAgentHomeScreen() {
    val sampleImmobili = listOf(
        Immobile("250.000", "Milano", "Via Centrale 10"),
        Immobile("180.000", "Torino", "Via Po 33")
    )
    AgentHomeScreen(
        immobili = sampleImmobili,
        onAddPropertyClick = {},
        onNotificheClick = {},
        onProfiloClick = {}
    )
}
