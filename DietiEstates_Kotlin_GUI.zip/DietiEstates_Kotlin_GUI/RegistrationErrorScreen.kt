import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview

@Composable
fun RegistrationErrorScreen(onRegisterClick: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }

    val isEmailError = email.isBlank()
    val isPasswordError = password.isBlank()
    val isFirstNameError = firstName.isBlank()
    val isLastNameError = lastName.isBlank()
    val isPhoneError = phone.isBlank()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("DietiEstates2024", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            isError = isEmailError,
            modifier = Modifier.fillMaxWidth()
        )
        if (isEmailError) ErrorText("CAMPO OBBLIGATORIO!")

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            isError = isPasswordError,
            modifier = Modifier.fillMaxWidth()
        )
        if (isPasswordError) ErrorText("CAMPO OBBLIGATORIO!")

        OutlinedTextField(
            value = firstName,
            onValueChange = { firstName = it },
            label = { Text("Nome") },
            isError = isFirstNameError,
            modifier = Modifier.fillMaxWidth()
        )
        if (isFirstNameError) ErrorText("CAMPO OBBLIGATORIO!")

        OutlinedTextField(
            value = lastName,
            onValueChange = { lastName = it },
            label = { Text("Cognome") },
            isError = isLastNameError,
            modifier = Modifier.fillMaxWidth()
        )
        if (isLastNameError) ErrorText("CAMPO OBBLIGATORIO!")

        OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("Telefono") },
            isError = isPhoneError,
            modifier = Modifier.fillMaxWidth()
        )
        if (isPhoneError) ErrorText("CAMPO OBBLIGATORIO!")

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = onRegisterClick, modifier = Modifier.fillMaxWidth()) {
            Text("Registrati")
        }
    }
}

@Composable
fun ErrorText(message: String) {
    Text(
        text = message,
        color = Color.Red,
        style = MaterialTheme.typography.bodySmall,
        modifier = Modifier.padding(bottom = 4.dp)
    )
}

@Preview(showBackground = true)
@Composable
fun RegistrationErrorScreenPreview() {
    RegistrationErrorScreen {}
}
