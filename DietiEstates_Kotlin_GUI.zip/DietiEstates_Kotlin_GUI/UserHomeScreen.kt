import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.tooling.preview.Preview

data class Immobile(val prezzo: String, val comune: String, val indirizzo: String)

@Composable
fun UserHomeScreen(email: String, immobili: List<Immobile>) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Utente: $email", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            horizontalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(onClick = { /* Cerca */ }) {
                Text("Cerca")
            }
            Button(onClick = { /* Notifiche */ }) {
                Text("Notifiche")
            }
            Button(onClick = { /* Profilo */ }) {
                Text("Profilo")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        Text("Elenco immobili:", style = MaterialTheme.typography.titleLarge)

        LazyColumn {
            items(immobili) { immobile ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("€${immobile.prezzo}", style = MaterialTheme.typography.titleMedium)
                        Text("${immobile.comune} - ${immobile.indirizzo}")
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewUserHomeScreen() {
    val sampleImmobili = listOf(
        Immobile("150.000", "Napoli", "Via degli Esami 30"),
        Immobile("200.000", "Roma", "Viale della Sapienza 12")
    )
    UserHomeScreen(email = "utente@example.com", immobili = sampleImmobili)
}
