import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.tooling.preview.Preview

@Composable
fun RichiestaPrenotazioneScreen(
    emailUtente: String,
    messaggioRichiesta: String,
    onAccetta: () -> Unit,
    onRifiuta: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text("Richiesta prenotazione", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(16.dp))
            Text("Email utente:", style = MaterialTheme.typography.titleSmall)
            Text(emailUtente, style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(16.dp))
            Text("Messaggio", style = MaterialTheme.typography.titleSmall)
            Text(messaggioRichiesta, style = MaterialTheme.typography.bodyMedium)
        }

        Row(
            horizontalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(onClick = onAccetta, modifier = Modifier.weight(1f)) {
                Text("Accetta")
            }
            Spacer(modifier = Modifier.width(16.dp))
            Button(onClick = onRifiuta, modifier = Modifier.weight(1f)) {
                Text("Rifiuta")
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewRichiestaPrenotazioneScreen() {
    RichiestaPrenotazioneScreen(
        emailUtente = "cliente@example.com",
        messaggioRichiesta = "Richiesta di appuntamento per visitare l'immobile in data 10/06 alle 15:00.",
        onAccetta = {},
        onRifiuta = {}
    )
}
