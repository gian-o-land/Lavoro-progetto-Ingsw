import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.tooling.preview.Preview

enum class StatoPrenotazione { ACCETTATA, RIFIUTATA }

@Composable
fun RiepilogoPrenotazioneScreen(
    stato: StatoPrenotazione,
    emailAgente: String,
    contenutoNotifica: String,
    onRichiediNuovoAppuntamento: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Riepilogo prenotazione", style = MaterialTheme.typography.headlineMedium)

        Text("Stato: ${stato.name}", color = if (stato == StatoPrenotazione.RIFIUTATA) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)

        Text("Agente: $emailAgente", style = MaterialTheme.typography.bodyLarge)
        Text(contenutoNotifica, style = MaterialTheme.typography.bodyMedium)

        if (stato == StatoPrenotazione.RIFIUTATA) {
            Button(onClick = onRichiediNuovoAppuntamento) {
                Text("Richiedi nuovo appuntamento")
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewRiepilogoPrenotazioneAccepted() {
    RiepilogoPrenotazioneScreen(
        stato = StatoPrenotazione.ACCETTATA,
        emailAgente = "agente@example.com",
        contenutoNotifica = "Prenotazione confermata per il 12/06 alle ore 17:00.",
        onRichiediNuovoAppuntamento = {}
    )
}

@Preview(showBackground = true)
@Composable
fun PreviewRiepilogoPrenotazioneRejected() {
    RiepilogoPrenotazioneScreen(
        stato = StatoPrenotazione.RIFIUTATA,
        emailAgente = "agente@example.com",
        contenutoNotifica = "L’agente ha rifiutato la fascia oraria richiesta.",
        onRichiediNuovoAppuntamento = {}
    )
}
