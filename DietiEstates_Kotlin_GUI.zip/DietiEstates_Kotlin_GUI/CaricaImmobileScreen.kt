import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview

@Composable
fun CaricaImmobileScreen(onCaricaClick: () -> Unit) {
    var prezzo by remember { mutableStateOf("") }
    var città by remember { mutableStateOf("") }
    var indirizzo by remember { mutableStateOf("") }
    var comune by remember { mutableStateOf("") }
    var categoria by remember { mutableStateOf("") }
    var quadratura by remember { mutableStateOf("") }
    var locali by remember { mutableStateOf("") }
    var bagni by remember { mutableStateOf("") }
    var piano by remember { mutableStateOf("") }
    var classeEnergetica by remember { mutableStateOf("") }
    var arredamento by remember { mutableStateOf("") }
    var fotoInserite by remember { mutableStateOf(false) }
    var planimetriaInserita by remember { mutableStateOf(false) }

    val caratteristiche = listOf("Ascensore", "Cucina", "Piscina", "Cantina", "Balcone", "Terrazzo")
    val selezionate = remember { mutableStateMapOf<String, Boolean>().apply {
        caratteristiche.forEach { put(it, false) }
    }}

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Carica Immobile", style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(value = prezzo, onValueChange = { prezzo = it }, label = { Text("Prezzo *") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
        OutlinedTextField(value = città, onValueChange = { città = it }, label = { Text("Città *") })
        OutlinedTextField(value = indirizzo, onValueChange = { indirizzo = it }, label = { Text("Indirizzo *") })
        OutlinedTextField(value = comune, onValueChange = { comune = it }, label = { Text("Comune *") })
        OutlinedTextField(value = categoria, onValueChange = { categoria = it }, label = { Text("Categoria") })
        OutlinedTextField(value = quadratura, onValueChange = { quadratura = it }, label = { Text("Quadratura") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
        OutlinedTextField(value = locali, onValueChange = { locali = it }, label = { Text("Locali") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
        OutlinedTextField(value = bagni, onValueChange = { bagni = it }, label = { Text("Bagni") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
        OutlinedTextField(value = piano, onValueChange = { piano = it }, label = { Text("Piano") })
        OutlinedTextField(value = classeEnergetica, onValueChange = { classeEnergetica = it }, label = { Text("Classe Energetica") })
        OutlinedTextField(value = arredamento, onValueChange = { arredamento = it }, label = { Text("Arredamento") })

        Text("Altre caratteristiche", style = MaterialTheme.typography.titleSmall)
        caratteristiche.forEach { caratteristica ->
            Row(
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .toggleable(
                        value = selezionate[caratteristica] == true,
                        onValueChange = { selezionate[caratteristica] = it }
                    )
                    .padding(4.dp)
            ) {
                Checkbox(
                    checked = selezionate[caratteristica] == true,
                    onCheckedChange = null
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(caratteristica)
            }
        }

        Button(onClick = { fotoInserite = true }) {
            Text(if (fotoInserite) "Foto inserite" else "Inserisci foto *")
        }

        Button(onClick = { planimetriaInserita = true }) {
            Text(if (planimetriaInserita) "Planimetria inserita" else "Inserisci planimetria")
        }

        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = onCaricaClick,
            enabled = prezzo.isNotBlank() && città.isNotBlank() && indirizzo.isNotBlank() && comune.isNotBlank() && fotoInserite,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Carica")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewCaricaImmobileScreen() {
    CaricaImmobileScreen(onCaricaClick = {})
}
