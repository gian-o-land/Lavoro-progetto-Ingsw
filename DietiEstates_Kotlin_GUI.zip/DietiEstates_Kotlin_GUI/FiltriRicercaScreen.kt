import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.tooling.preview.Preview

@Composable
fun FiltriRicercaScreen(onCercaClick: () -> Unit) {
    var prezzoMin by remember { mutableStateOf("") }
    var prezzoMax by remember { mutableStateOf("") }
    var localiMin by remember { mutableStateOf("") }
    var localiMax by remember { mutableStateOf("") }
    var bagniMin by remember { mutableStateOf("") }
    var bagniMax by remember { mutableStateOf("") }
    var piano by remember { mutableStateOf("") }
    var classeEnergetica by remember { mutableStateOf("") }
    var arredamento by remember { mutableStateOf("") }

    val caratteristiche = listOf("Ascensore", "Cucina", "Piscina", "Cantina", "Balcone", "Terrazzo")
    val selezionate = remember { mutableStateMapOf<String, Boolean>().apply {
        caratteristiche.forEach { put(it, false) }
    }}

    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Filtri Ricerca", style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(
            value = prezzoMin, onValueChange = { prezzoMin = it },
            label = { Text("Prezzo Min") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
        OutlinedTextField(
            value = prezzoMax, onValueChange = { prezzoMax = it },
            label = { Text("Prezzo Max") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )

        OutlinedTextField(
            value = localiMin, onValueChange = { localiMin = it },
            label = { Text("Locali Min") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
        OutlinedTextField(
            value = localiMax, onValueChange = { localiMax = it },
            label = { Text("Locali Max") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )

        OutlinedTextField(
            value = bagniMin, onValueChange = { bagniMin = it },
            label = { Text("Bagni Min") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
        OutlinedTextField(
            value = bagniMax, onValueChange = { bagniMax = it },
            label = { Text("Bagni Max") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )

        OutlinedTextField(
            value = piano, onValueChange = { piano = it },
            label = { Text("Piano") }
        )
        OutlinedTextField(
            value = classeEnergetica, onValueChange = { classeEnergetica = it },
            label = { Text("Classe Energetica") }
        )
        OutlinedTextField(
            value = arredamento, onValueChange = { arredamento = it },
            label = { Text("Arredamento") }
        )

        Text("Altre caratteristiche", style = MaterialTheme.typography.titleMedium)
        caratteristiche.forEach { caratteristica ->
            Row(
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .toggleable(
                        value = selezionate[caratteristica] == true,
                        onValueChange = { selezionate[caratteristica] = it }
                    )
                    .padding(4.dp)
            ) {
                Checkbox(
                    checked = selezionate[caratteristica] == true,
                    onCheckedChange = null
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(caratteristica)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onCercaClick, modifier = Modifier.fillMaxWidth()) {
            Text("Cerca")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewFiltriRicercaScreen() {
    FiltriRicercaScreen(onCercaClick = {})
}
