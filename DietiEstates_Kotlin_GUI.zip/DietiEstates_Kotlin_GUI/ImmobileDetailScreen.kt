import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.tooling.preview.Preview

data class ImmobileDettaglio(
    val prezzo: String,
    val comune: String,
    val indirizzo: String,
    val descrizione: String,
    val caratteristiche: List<String>
)

@Composable
fun ImmobileDetailScreen(immobile: ImmobileDettaglio, onChiama: () -> Unit, onPrenota: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Text("€${immobile.prezzo}", style = MaterialTheme.typography.headlineMedium)
        Text("${immobile.comune} - ${immobile.indirizzo}", style = MaterialTheme.typography.bodyLarge)
        Spacer(modifier = Modifier.height(16.dp))

        Text("Descrizione", style = MaterialTheme.typography.titleMedium)
        Text(immobile.descrizione, style = MaterialTheme.typography.bodyMedium)
        Spacer(modifier = Modifier.height(16.dp))

        Text("Caratteristiche", style = MaterialTheme.typography.titleMedium)
        Column {
            immobile.caratteristiche.forEach {
                Text("• $it", style = MaterialTheme.typography.bodyMedium)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Row(
            horizontalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(onClick = onChiama) {
                Text("Chiama")
            }
            Button(onClick = onPrenota) {
                Text("Prenota")
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewImmobileDetailScreen() {
    val sample = ImmobileDettaglio(
        prezzo = "150.000",
        comune = "Napoli",
        indirizzo = "Via degli Esami 30",
        descrizione = "Appartamento luminoso con tre camere da letto e cucina abitabile.",
        caratteristiche = listOf("Ascensore", "Balcone", "Cucina", "Terrazzo")
    )
    ImmobileDetailScreen(sample, onChiama = {}, onPrenota = {})
}
